package com.sbi.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.sbi.model.CustomerLogin;
import com.sbi.model.CustomerRegistraton;
import com.sbi.repo.CustomerLoginRepo;
import com.sbi.service.CustomerLoginService;

@Service
public class CustomerLoginImpl implements CustomerLoginService {

	@Autowired
	private CustomerLoginRepo repo;

	@Autowired
	private RestTemplate template;

	@Override
	public String loginCustomer(CustomerLogin login) {
		
		

		CustomerRegistraton result = template
				.getForObject("http://YonoBusinessCorporateCustomerRegistration/corpcustomer/getcorpcustbyusername/"
						+ login.getUsername(), CustomerRegistraton.class);

		System.out.println(result);
		

		if (login.getUsername().equals(result.getUsername()) && login.getPassword().equals(result.getPassword())) {

			System.out.println(result);
			repo.save(login);

			return "Corporate Customer Login Succesfully::";
		}

		/*
		 * if((login==null)) {
		 * 
		 * repo.save(login);
		 * 
		 * return "Corporate Login Success::";
		 * 
		 * }
		 */

		return "Invalid Username & Password";

	}

}
