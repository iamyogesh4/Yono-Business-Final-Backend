package com.sbi.model;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class CustomerRegistraton {
	
    private Integer cid;
	
	private String cname;
	
	private Integer cage;
	
	private String cemail;
	
	private Long cmobileNumber;
	
	private Integer csal;
	
	private String cgender;
	
	private String username;
	
	private String password;

	private String confirmpawword;

}
