package com.sbi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YonoBusinessCorporateCustomerLoginApplicationTests {

	@Test
	void contextLoads() {
	}

}
